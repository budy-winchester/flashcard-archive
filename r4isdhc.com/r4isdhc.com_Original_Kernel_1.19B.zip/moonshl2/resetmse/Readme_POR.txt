Se voc� copiar para esta pasta um arquivo NDS de reset do firmware compat�vel com o seu flashcart, voc� poder� sair do MoonShell2 e voltar para o firmware.
Eu abandonei o desenvolvimento da complicada estrutura do antigo MoonShell. A estrutura MSE j� n�o est� mais na VRAM.
Ele apenas carrega o arquivo "nomedoflashcart.nds". Para o nome do flashcart, por favor usar o DLDI ID do flashcart (por exemplo, M3 DS Real seria M3DS.nds).

ex:
SCDS.nds => para SuperCard DS One
CEVO.nds => para CycloDS
DLMS.nds => para DSLink
R4TF.nds => para R4

~Traduzido por Axel-MaV
