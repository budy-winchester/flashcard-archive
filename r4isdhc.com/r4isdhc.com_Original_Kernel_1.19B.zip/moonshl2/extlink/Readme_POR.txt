
Voc� pode definir ao MoonShell2 extens�es de arquivos para serem abertas usando aplica��es externas.
Mesmo que voc� n�o use esta fun��o, n�o exclua esta pasta.

O arquivo NDS definir� qual arquivo ser� aberto.
Por exemplo, se voc� copiar o arquivo "ipk.nds" para esta pasta, se voc� abrir um arquivo IPK o "ipk.nds" ser� automaticamente carregado.
Se voc� colocar "mp3.nds" ou "jpg.nds" nesta pasta, a fun��o Extended Link ter� prioridade sobre o leitor/visualizador interno do MoonShell.

Se voc� tentar definir um arquivo incompat�vel para a fun��o Extended Link, o arquivo ser� aberto normalmente.
Por exemplo, se voc� renomear o "ReinMoon.nds" para "sav.nds" e colocar nesta pasta, sempre que voc� abrir um arquivo .sav o ReinMoon ser� carregado, e n�o o save.

� facil criar arquivos compat�veis com a fun��o Extended Link (fiz o mais simples poss�vel).
Por favor leia o "moonshl2_extlink_for_developer.txt" (indispon�vel) para mais detalhes.
Ele tamb�m descreve como sair de uma homebrew e voltar para o MoonShell2 (um pouco complicado)

~Traduzido por Axel-MaV