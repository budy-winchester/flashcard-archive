
I am using the machine translation.
This is a very poor translation.
Please question Moonlight if there is an item that cannot be understood.

Most lines are longer than the width of the screen.
My translation is a long sentence. (It is not good.)

When you translate, I am very glad. Please send me mail (moonshellnds@gmail.com).
To our regret, gmail tends to delete a big attached file.

The disk check messages can be debugged by starting (booting) while pushing the SELECT button.

